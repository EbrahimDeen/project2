<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', '');
   define('DB_DATABASE', 'bankingsystem');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
   $conStr = sprintf("mysql:host=%s;dbname=%s", DB_SERVER, DB_DATABASE);
   try {
      $pdo = new PDO($conStr, DB_USERNAME, DB_PASSWORD);
  } catch (PDOException $e) {
      die($e->getMessage());
  }
?>